const net = require('net');

// Cấu hình từ môi trường
const PORT = process.env.PORT || 30127;
const SECRET_KEY = process.env.TUNNEL_SECRET || 'protectedbytkyandgemini';

const tunnels = new Map(); // serviceId -> { socket, timeout }
const pendingConnections = new Map(); // connId -> { client, buffer }

const server = net.createServer((socket) => {
  const addr = `${socket.remoteAddress}:${socket.remotePort}`;
  let identified = false;
  let buffer = Buffer.alloc(0);

  const onData = (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    if (buffer.length < 10) return; // Chờ đủ dữ liệu để nhận diện

    identified = true;
    socket.removeListener('data', onData);
    const text = buffer.toString('utf8');

    // 1. XỬ LÝ KẾT NỐI ĐIỀU KHIỂN (TUNNEL CONTROL)
    if (text.startsWith('TUNNEL|')) {
      const parts = text.split('\n')[0].split('|');
      const serviceId = parts[1];
      const receivedKey = parts[2];

      if (receivedKey !== SECRET_KEY) {
        console.log(`[AUTH] Từ chối kết nối không đúng Secret Key từ ${addr}`);
        socket.end('ERROR: Unauthorized\n');
        return;
      }
      handleTunnel(socket, serviceId);
      return;
    }

    // 2. XỬ LÝ KẾT NỐI DỮ LIỆU (DATA BRIDGE)
    if (text.startsWith('DATA|')) {
      const line = text.split('\n')[0];
      const remaining = buffer.slice(line.length + 1);
      const parts = line.split('|');
      handleDataConnection(socket, parts[1], parts[2], remaining);
      return;
    }

    // 3. XỬ LÝ KẾT NỐI TỪ CLIENT (NGƯỜI DÙNG)
    autoDetectAndHandleClient(socket, buffer, addr);
  };

  socket.on('data', onData);
  socket.on('error', (err) => console.error(`[${addr}] Lỗi:`, err.message));
  
  // Timeout nếu kết nối vào mà không gửi gì
  setTimeout(() => { if (!identified) socket.destroy(); }, 10000);
});

function handleTunnel(controlSocket, serviceId) {
  // Dọn dẹp tuyệt đối nếu serviceId này đã tồn tại (Workflow cũ)
  if (tunnels.has(serviceId)) {
    console.log(`[CLEANUP] Đóng phiên cũ của ${serviceId} để nhận phiên mới`);
    const old = tunnels.get(serviceId);
    clearTimeout(old.timeout);
    old.socket.destroy();
    
    // Xóa các kết nối đang chờ cũ để tránh gửi nhầm dữ liệu
    for (let [id, conn] of pendingConnections) {
      conn.client.destroy();
      pendingConnections.delete(id);
    }
  }

  const setHeartbeat = () => {
    return setTimeout(() => {
      console.log(`[TIMEOUT] ${serviceId} quá lâu không gửi PING. Ngắt kết nối.`);
      controlSocket.destroy();
    }, 35000); // Cho phép tối đa 35 giây (3 lần PING 10s + 5s bù trừ)
  };

  tunnels.set(serviceId, { socket: controlSocket, timeout: setHeartbeat() });
  controlSocket.write('OK\n');
  console.log(`[TUNNEL] ${serviceId} đã đăng ký thành công từ GitHub Runner.`);

  controlSocket.on('data', (chunk) => {
    const msg = chunk.toString().trim();
    if (msg === 'PING') {
      // Reset đồng hồ đếm ngược Heartbeat
      const entry = tunnels.get(serviceId);
      if (entry) {
        clearTimeout(entry.timeout);
        entry.timeout = setHeartbeat();
      }
      return;
    }
    // Xử lý các lệnh khác (nếu có)
  });

  controlSocket.on('close', () => {
    const entry = tunnels.get(serviceId);
    if (entry && entry.socket === controlSocket) {
      clearTimeout(entry.timeout);
      tunnels.delete(serviceId);
      console.log(`[TUNNEL] ${serviceId} đã thoát.`);
    }
  });
}

function autoDetectAndHandleClient(clientSocket, buffer, addr) {
  let serviceId = 'default';
  // Nhận diện giao thức (Magic Bytes)
  if (buffer.slice(0, 3).equals(Buffer.from([0x03, 0x00, 0x00]))) serviceId = 'rdp';
  else if (buffer.slice(0, 3).toString() === 'SSH') serviceId = 'ssh';
  else if (buffer.toString().includes('GET ')) serviceId = 'http';

  const tunnelEntry = tunnels.get(serviceId);
  if (!tunnelEntry) {
    console.log(`[CLIENT] ${serviceId} chưa sẵn sàng (Workflow chưa chạy)`);
    clientSocket.end();
    return;
  }

  const connId = Math.random().toString(36).substring(2, 11);
  pendingConnections.set(connId, { client: clientSocket, buffer: buffer });
  
  tunnelEntry.socket.write(`NEW|${connId}\n`);
  console.log(`[CLIENT] Yêu cầu kết nối mới [${serviceId}] - ID: ${connId}`);

  clientSocket.on('error', () => pendingConnections.delete(connId));
}

function handleDataConnection(dataSocket, serviceId, connId, initialData) {
  const pending = pendingConnections.get(connId);
  if (!pending) {
    dataSocket.destroy();
    return;
  }
  pendingConnections.delete(connId);

  const clientSocket = pending.client;
  if (pending.buffer) dataSocket.write(pending.buffer);
  if (initialData.length > 0) clientSocket.write(initialData);

  clientSocket.pipe(dataSocket);
  dataSocket.pipe(clientSocket);

  const cleanup = () => {
    clientSocket.destroy();
    dataSocket.destroy();
  };
  clientSocket.on('close', cleanup);
  dataSocket.on('close', cleanup);
}

server.listen(PORT, '0.0.0.0', () => {
  console.log(`=== SMART TUNNEL SERVER RUNNING ON PORT ${PORT} ===`);
  console.log(`Bảo mật: ${SECRET_KEY ? 'ĐÃ BẬT' : 'CẢNH BÁO: CHƯA BẬT'}`);
});
